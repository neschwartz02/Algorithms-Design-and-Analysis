import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * Driver class for the GraphAnalyis class.
 * 
 * @author Natalie Schwartzenberger
 * @version Feb. 18 2021
 *
 */
public class GraphDriver {

	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("What type of graph did you want to create? ");
			String graphType = sc.nextLine();
			System.out.println("How do you want to store the graph? ");
			String storageType = sc.nextLine();
			System.out.println("What is the name of the file where the graph is stored? ");
			String fileName = sc.nextLine();
			System.out.println("");
			
			Graph<String> createdGraph = MakeGraph.createGraph(graphType, storageType, fileName);
			GraphAnalysis analyzeGraph = new GraphAnalysis(createdGraph);
			
			if(analyzeGraph.isConnected()) {
				System.out.println("That graph is connected, yay!");
				System.out.println("");
				System.out.println("The following vertices are vertex cuts on their own:");
				for(String vertex : analyzeGraph.getCriticalVertices()) {
					System.out.println(vertex);
				}
				System.out.println("");
			}  else {
				System.out.println("That graph is disconnected, uh-oh!");
				System.out.println("");
			}
			
			System.out.println("Enter the set you would like to check for a Vertex Cut."
					+ " Write one vertex per line and END when you are finished.");
			
			Set<String> userVertices = new HashSet<String>();
			boolean isEnd = false;
			while(!isEnd) {
				String input = sc.nextLine().toLowerCase();
				if(input.equals("end")) {
					isEnd = true;
				} else {
					userVertices.add(input);
				}	
			}
			
			if(analyzeGraph.isVertexCut(userVertices)) {
				System.out.println("");
				System.out.println("That is a vertex cut!");
			} else {
				System.out.println("");
				System.out.println("That is not a vertext cut!");
			}
		}
	}
}
