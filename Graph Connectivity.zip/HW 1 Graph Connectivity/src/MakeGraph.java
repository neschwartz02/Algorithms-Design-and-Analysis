import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * A class that reads in and creates a Graph object
 * 
 * @author Natalie Schwartzenberger
 * @version Feb. 18 2021
 *
 */
public class MakeGraph {

	/**
	 * Static method that creates a graph
	 * 
	 * @param graphType   the type of graph to be used (directed or undirected)
	 * @param storageType the method of storage for the graph (matrix or list)
	 * @param fileName    the filename containing the graph's data
	 * @return a graph specified to the user's needs
	 */
	public static Graph<String> createGraph(String graphType, String storageType, String fileName) {
		Graph<String> myGraph;
		ArrayList<Pair<String, String>> edges = read(fileName);

		if (storageType.equals("matrix")) {
			if (graphType.equals("directed")) {
				myGraph = new DiGraphMatrix<String>(edges);
			} else {
				myGraph = new GraphMatrix<String>(edges);
			}
		} else {
			if (graphType.equals("directed")) {
				myGraph = new DiGraphList<String>(edges);
			} else {
				myGraph = new GraphList<String>(edges);
			}
		}
		return myGraph;
	}

	/**
	 * Static method that reads in the file where the graph data is stored
	 * 
	 * @param fileName name of the file to be used
	 * @return a List of all the edges in the file
	 */
	public static ArrayList<Pair<String, String>> read(String fileName) {
		ArrayList<Pair<String, String>> edgesList = new ArrayList<Pair<String, String>>();

		try {
			Scanner inFile = new Scanner(new File(fileName));

			while (inFile.hasNextLine()) {
				String newLine = inFile.nextLine();
				String[] splitLine = newLine.split(",");
				Pair<String, String> pairEdge = new Pair<String, String>(splitLine[0], splitLine[1]);
				edgesList.add(pairEdge);
			}

		} catch (java.io.FileNotFoundException e) {
			System.out.println("No such file: " + fileName);
		}
		return edgesList;
	}
}
