import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;
import java.util.List;

/**
 * A class that takes in a graph and analyzes it
 * Algorithms Analysis HW 1: Graph Connectivity
 * 
 * @author Natalie Schwartzenberger
 * @version Feb. 18 2021
 *
 */
public class GraphAnalysis {
	public Graph<String> storeGraph;
	public Set<String> allVertices;

	public GraphAnalysis(Graph<String> g) {
		this.storeGraph = g;
		this.allVertices = storeGraph.getVertices();
	}

	/**
	 * Determines if the graph is connected
	 * 
	 * @return true if the graph is connected, false if it is not connected
	 */
	public boolean isConnected() {
		boolean hasPath = true;

		for (String vertex : this.allVertices) {
			for (String next : this.allVertices) {
				hasPath = DFS(storeGraph, vertex, next);
				if (!hasPath) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Private helper method for isConnected(), determines if there is a path
	 * between a starting point and a given goal
	 * 
	 * @param g     the graph to be used
	 * @param start the vertex where the search begins
	 * @param goal  the vertex that needs to be checked to see if it has a path from
	 *              start
	 * @return true if there is a path between the given vertices, false if not
	 */
	private static <E> boolean DFS(Graph<E> g, E start, E goal) {
		List<E> startPath = new ArrayList<E>();
		startPath.add(start);

		Stack<List<E>> paths = new Stack<List<E>>();
		paths.push(startPath);

		while (!paths.isEmpty()) {
			List<E> pathToExtend = paths.pop();
			E current = pathToExtend.get(pathToExtend.size() - 1);
			if (current.equals(goal)) {
				return true;
			} else {
				for (E adj : g.getAllAdjacent(current)) {
					if (!pathToExtend.contains(adj)) {
						List<E> copy = new ArrayList<E>(pathToExtend);
						copy.add(adj);
						paths.push(copy);
					}
				}
			}
		}
		return false;
	}

	/**
	 * Determines if a set of vertices is a vertex cut
	 * 
	 * @param vertices the vertices to be checked for a vertex cut
	 * @return true if the set of vertices is a vertex cut, false if not
	 */
	public boolean isVertexCut(Set<String> vertices) {
		Set<String> keepSet = new HashSet<String>();
		for (String vertex : this.allVertices) {
			keepSet.add(vertex);
		}

		for (String vertexCheck : vertices) {
			this.allVertices.remove(vertexCheck);
		}
		Set<String> cutVertices = this.allVertices;
		this.allVertices = keepSet;

		boolean hasPath = true;
		for (String vertex : cutVertices) {
			for (String next : cutVertices) {
				hasPath = DFSMod(storeGraph, vertex, next, vertices);
				if (!hasPath) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * A private helper method that checks to see if a graph is connected, modified
	 * to ignore certain vertices as if they are not a part of the graph
	 *
	 * @param g        the graph to be searched
	 * @param start    the vertex to start on
	 * @param goal     the vertex to find a path to from the starting vertex
	 * @param vertices a set of vertices to be ignored when searching for a path
	 * @return true if the path is connected, false if not
	 */
	private static <E> boolean DFSMod(Graph<E> g, E start, E goal, Set<String> vertices) {
		List<E> startPath = new ArrayList<E>();
		startPath.add(start);

		Stack<List<E>> paths = new Stack<List<E>>();
		paths.push(startPath);

		while (!paths.isEmpty()) {
			List<E> pathToExtend = paths.pop();
			E current = pathToExtend.get(pathToExtend.size() - 1);
			if (current.equals(goal)) {
				return true;
			} else {
				for (E adj : g.getAllAdjacent(current)) {
					if (vertices.contains(adj)) { // skips the numbers contained in vertices
						continue;
					} else if (!pathToExtend.contains(adj)) {
						List<E> copy = new ArrayList<E>(pathToExtend);
						copy.add(adj);
						paths.push(copy);
					}
				}
			}
		}
		return false;
	}

	/**
	 * Checks to see which individual vertices in a graph are vertex cuts
	 * 
	 * @return a set of all the vertex cuts in a graph
	 */
	public Set<String> getCriticalVertices() {
		Set<String> vertexCuts = new HashSet<String>();
		ArrayList<HashSet<String>> setsList = new ArrayList<HashSet<String>>();

		for (String vertex : this.allVertices) {
			HashSet<String> set = new HashSet<String>();
			set.add(vertex);
			setsList.add(set);
		}

		for (int i = 0; i < setsList.size(); i++) {
			Set<String> checkSet = setsList.get(i);
			if (this.isVertexCut(checkSet)) {
				String setString = checkSet.toString();
				vertexCuts.add(setString);
			}
		}
		return vertexCuts;
	}
}
