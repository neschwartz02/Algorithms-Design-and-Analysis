import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

/**
 * A class that plays a game of disHonest hangman (makes guessing harder for the user)
 * 
 * @author Natalie Schwartzenberger
 * @version March 10 2021
 */
public class DishonestHangman implements Hangman {
	protected boolean wordGuessed;
	String wordToDisplay;
	String finalWord;
	private int guesses;

	private Map<String, HashSet<String>> remainingWords;
	private Set<String> initialWords;

	private Set<Character> guessedChars;
	protected ArrayList<String> words;

	/**
	 * Creates a game of dishonest hangman 
	 * 
	 * @param fileName
	 */
	public DishonestHangman(String fileName) {
		this.guessedChars = new HashSet<Character>();
		this.words = new ArrayList<String>();
		this.remainingWords = new HashMap<String, HashSet<String>>();
		this.initialWords = new HashSet<String>();

		this.read(fileName);

		this.guesses = 6;
		this.wordGuessed = false;
		this.makePossList();

		this.updateRedactMap(initialWords);
	}

	/**
	 * Reads in a file and adds the words in the file to a list
	 * 
	 * @param fileName
	 */
	private void read(String fileName) {
		try {
			Scanner inFile = new Scanner(new File(fileName));

			while (inFile.hasNextLine()) {
				String newLine = inFile.nextLine();
				this.words.add(newLine);
			}

		} catch (java.io.FileNotFoundException e) {
			System.out.println("No such file: " + fileName);
		}
	}

	/**
	 * Makes a list of all the words in the dictionary of a random length between
	 * 4-12 characters long
	 * 
	 */
	protected void makePossList() {
		Random rand = new Random();
		int randLength = rand.nextInt(12 - 4) + 4;

		this.wordToDisplay = "";
		for (int i = 0; i < randLength; i++) {
			this.wordToDisplay += "-";
		}

		for (int i = 0; i < this.words.size(); i++) {
			if (this.words.get(i).length() == randLength) {
				this.initialWords.add(this.words.get(i));
			}
		}
		
	}

	/**
	 * Puts all characters of a single word into a map
	 * 
	 * @return the characters of a word as a map
	 */
	public Map<Character, Integer> getCharacters(Set<String> words) {
		Map<Character, Integer> chars = new HashMap<Character, Integer>();

		for (String word : words) {
			for (int i = 0; i < word.length(); i++) {
				char charVal = Character.valueOf(word.charAt(i));
				if (chars.containsKey(charVal)) {
					chars.replace(charVal, chars.get(charVal) + 1);
				} else {
					chars.put(charVal, 1);
				}
			}
		}
		return chars;
	}

	/**
	 * If the game is not over, it returns the selected word with unguessed letters
	 * redacted with an -, if the game is over it returns the actual word
	 * 
	 * @return the redacted word if the game is not over, the actual word if the
	 *         game is over.
	 */
	public String getDisplayWord() {
		if (!gameOver()) {
			return wordToDisplay;
		} else {
			return finalWord;
		}
	}

	/**
	 * Private helper method that updates the string with correct letters from the
	 * user
	 * 
	 * @param rWord      the string to be updated
	 * @param wordLength the length of the word to be guessed
	 * @return updated string with new letters
	 */
	private String makeRedact(String word, String rWord) {
		String wordUpdate = rWord;
		int l = word.length();

		for (int i = 0; i < l; i++) {
			for (char letter : this.guessedChars) {
				if (word.charAt(i) == letter) {
					wordUpdate = wordUpdate.substring(0, i) + letter + wordUpdate.substring(i + 1);
				}
			}
		}
		return wordUpdate;
	}

	/**
	 * Makes a map of redactions paired with a list of words that matches each redaction,
	 * picks the redaction with the largest list of words and updates the display word based
	 * on the redaction with the largest amount of words.
	 * 
	 * @param The set of words to make into a redaction-list map
	 */
	private void updateRedactMap(Set<String> wordSet) {
		for (String word : wordSet) {
			if (wordSet.size() <= 1) {
				this.finalWord = word;
			}

			HashSet<String> tempList = new HashSet<String>();
			String newRedact = makeRedact(word, this.wordToDisplay);

			if (this.remainingWords.containsKey(newRedact)) {
				HashSet<String> mapList = new HashSet<String>();

				mapList = this.remainingWords.get(newRedact);
				tempList.add(word);
				tempList.addAll(mapList);

				this.remainingWords.replace(newRedact, tempList);

			} else {
				tempList.add(word);
				this.remainingWords.put(newRedact, tempList);
			}
		}

		String maxKey = "";
		int counter = 0;

		for (String key : this.remainingWords.keySet()) { // adds the key w/ largest value to the maxList
			int currLen = this.remainingWords.get(key).size();
			if (currLen > counter) {
				counter = currLen;
				maxKey = key;
			}
		}

		Set<String> removeWords = new HashSet<String>();
		for (String key : this.remainingWords.keySet()) { // deletes all keys that aren't the max key from the maxList
			if (!(key.equals(maxKey))) {
				removeWords.add(key);
			}
		}
		this.remainingWords.keySet().removeAll(removeWords);
		this.wordToDisplay = maxKey;
	}

	/**
	 * Records the guess and returns a message describing the result.
	 * 
	 * @param let the character being guessed
	 * @return a message with the result of the guess
	 */
	public String makeGuess(char let) {
		Map<Character, Integer> validChars = new HashMap<Character, Integer>();
		Set<String> updateRemaining = new HashSet<String>();

		if(!(guessedChars.isEmpty())) {
			updateRemaining = this.remainingWords.get(this.wordToDisplay);
			validChars = this.getCharacters(updateRemaining);
			this.updateRedactMap(updateRemaining);
		}

		if (this.guessedChars.contains(let)) {
			return "You have already guessed " + let + ".";

		} else if (validChars.containsKey(let)) {
			this.guessedChars.add(let);
			return "You guessed correctly! There are(is) " + validChars.get(let) + " " + let + "'s.";

		} else {
			this.guessedChars.add(let);
			this.guesses--;
			return "You guessed wrong, there are no " + let + "'s. You have " + guessesRemaining() + " guesses left.";
		}
	}

	/**
	 * Determines if the game is over. The game is considered over when the player
	 * has used all their wrong guesses or the player has correctly guesses the word
	 * 
	 * @return true if the game is over, false otherwise
	 */
	public boolean gameOver() {
		if (this.guesses <= 0 || this.wordGuessed) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Gets how many wrong guesses are remaining.
	 * 
	 * @return the number of wrong guesses remaining
	 */
	public int guessesRemaining() {
		return this.guesses;
	}
}
