import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

/**
 * A class that plays honest hangman (the classic type of hangman)
 * 
 * @author Natalie Schwartzenberger
 *	@version March 10 2021
 */
public class HonestHangman implements Hangman {
	protected boolean wordGuessed;
	protected String redactWord;
	private String guessWord;
	private int guesses;
	
	private Map<Character, Integer> characters;
	private Set<Character> guessedChars;
	protected ArrayList<String> words;
	

	/**
	 * Creates a game of honest hangman (only chooses one word for the guess)
	 * 
	 * @param fileName the name of the file to be used
	 */
	public HonestHangman(String fileName) {
		this.guessedChars = new HashSet<Character>();
		this.words = new ArrayList<String>();
		read(fileName);

		this.guessWord = getRandomWord(0, this.words.size());
		this.characters = getCharacters(guessWord);

		this.guesses = 6;
		this.wordGuessed = false;

		this.redactWord = "";
		for (int i = 0; i < this.guessWord.length(); i++) {
			this.redactWord += "-";
		}
	}

	/**
	 * Reads in a file and adds the words in the file to a list
	 * 
	 * @param fileName the name of the file to be used
	 */
	public void read(String fileName) {

		try {
			Scanner inFile = new Scanner(new File(fileName));

			while (inFile.hasNextLine()) {
				String newLine = inFile.nextLine();
				this.words.add(newLine);

			}
		} catch (java.io.FileNotFoundException e) {
			System.out.println("No such file: " + fileName);
		}
	}

	/**
	 * Gets a random word from the dictionary
	 * 
	 * @return a random word
	 */
	public String getRandomWord(int min, int max) {
		Random rand = new Random();
		String randWord = words.get(rand.nextInt(max - min) + min);
		return randWord;
	}

	/**
	 * Puts all characters of a word into a map
	 * 
	 * @return the characters of a word as a map
	 */
	public Map<Character, Integer> getCharacters(String word) {
		Map<Character, Integer> chars = new HashMap<Character, Integer>();

		for (int i = 0; i < word.length(); i++) {
			char charVal = Character.valueOf(word.charAt(i));
			if (chars.containsKey(charVal)) {
				chars.replace(charVal, chars.get(charVal) + 1);
			} else {
				chars.put(charVal, 1);
			}
		}
		return chars;
	}

	/**
	 * If the game is not over, it returns the selected word with unguessed letters
	 * redacted with an -, if the game is over it returns the actual word
	 * 
	 * @return the redacted word if the game is not over, the actual word if the
	 *         game is over.
	 */
	public String getDisplayWord() {
		int l = this.guessWord.length();

		if (!gameOver()) {
			if (guessedChars.isEmpty()) {
				return this.redactWord;
			} else {
				redactWord = updateWord(this.redactWord, l);
				if (this.redactWord.equals(this.guessWord)) {
					this.wordGuessed = true;
				}

				return this.redactWord;
			}
		} else {
			return this.guessWord;
		}
	}

	/**
	 * Private helper method that updates the string with correct letters from the
	 * user
	 * 
	 * @param rWord      the string to be updated
	 * @param wordLength the length of the word to be guessed
	 * @return updated string with new letters
	 */
	private String updateWord(String rWord, int wordLength) {
		String wordUpdate = rWord;

		for (int i = 0; i < wordLength; i++) {
			for (char letter : this.guessedChars) {
				if (this.guessWord.charAt(i) == letter) {
					wordUpdate = wordUpdate.substring(0, i) + letter + wordUpdate.substring(i + 1);
				}
			}
		}
		return wordUpdate;
	}
	
	/**
	 * Records the guess and returns a message describing the result.
	 * 
	 * @param let the character being guessed
	 * @return a message with the result of the guess
	 */
	public String makeGuess(char let) {
		if (this.guessWord.equals(this.redactWord)) {
			this.wordGuessed = true;
		}

		if (this.guessedChars.contains(let)) {
			return "You have already guessed " + let + ".";

		} else if (this.characters.containsKey(let)) {
			this.guessedChars.add(let);
			return "You guessed correctly! There are(is) " + this.characters.get(let) + " " + let + "'s.";

		} else {
			this.guessedChars.add(let);
			this.guesses--;
			return "You guessed wrong, there are no " + let + "'s. You have " + guessesRemaining() + " guesses left.";
		}
	}

	/**
	 * Determines if the game is over. The game is considered over when the player
	 * has used all their wrong guesses or the player has correctly guesses the word
	 * 
	 * @return true if the game is over, false otherwise
	 */
	public boolean gameOver() {
		if (this.guesses <= 0 || this.wordGuessed) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Gets how many wrong guesses are remaining.
	 * 
	 * @return the number of wrong guesses remaining
	 */
	public int guessesRemaining() {
		return this.guesses;
	}

}
