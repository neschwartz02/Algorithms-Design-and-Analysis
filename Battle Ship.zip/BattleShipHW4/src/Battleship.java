import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * A class that solves a Battleship puzzle
 * 
 * @author Natalie Schwartzenberger
 * @version April 2021
 *
 */
public class Battleship {
	private Map<Integer, Integer> boatsRem;
	private Map<String, Integer> boatPieces;
	private ArrayList<Integer> piecesList;
	private int boardSize;
	private String[][] currBoard;

	public Battleship(String filename) {
		boatsRem = new HashMap<Integer, Integer>();
		boatPieces = new HashMap<String, Integer>();
		piecesList = new ArrayList<Integer>();

		makeBoard(filename);
	}

	/**
	 * Checks to see if the board has successfully been solved
	 * 
	 * @return true if the puzzle has been solved, false if not
	 */
	public boolean isSolvable() {
		if (this.solveBoard()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Returns the solution to the problem if it is solvable, if not solvable it
	 * returns a message stating there is no solution to the problem
	 * 
	 * @return the solution to the problem or an error message
	 */
	public String displaySolution() {
		if (isSolvable()) {
			String s = "  ";
			for (int i = 0; i < this.boardSize; i++) {
				s += String.valueOf(piecesList.get(i));
			}
			s += "\n";
			s += "  ----------  ";
			s += "\n";
			for (int r = 0; r < this.boardSize; r++) {
				s += String.valueOf(piecesList.get(r + 10));
				s += "|";
				for (int c = 0; c < this.boardSize; c++) {
					s += currBoard[r][c];
				}
				s += "|" + "\n";
			}
			s += "  ----------  ";
			return s;
		} else {
			return ("There is no solution to this Battleship board.");
		}

	}

	/**
	 * Reads in a file and populates a battleship board with the provided
	 * information, using "-" for a unfilled space
	 * 
	 * @param fileName  the name of the file to be used to populate the board
	 * @param boardSize the size of the square game board
	 * @return the initial board for a battleship game
	 */
	public void makeBoard(String filename) {
		try {
			Scanner infile = new Scanner(new File(filename));
			this.boardSize = infile.nextInt();
			this.boatsRem.put(4, infile.nextInt());
			this.boatsRem.put(3, infile.nextInt());
			this.boatsRem.put(2, infile.nextInt());
			this.boatsRem.put(1, infile.nextInt());

			// Puts the column boat counts into the map of boat pieces
			for (int i = 0; i < this.boardSize; i++) {
				int num = infile.nextInt();
				this.piecesList.add(num);
				String loc = Integer.toString(i);
				this.boatPieces.put("c" + loc, num); // 'c' denotes that these are columns
			}

			this.currBoard = new String[this.boardSize][this.boardSize];
			String str = infile.nextLine();

			while (infile.hasNextLine()) {
				for (int r = 0; r < this.boardSize; r++) {
					str = infile.nextLine();
					String loc = Integer.toString(r);
					String rowPieces = "" + str.charAt(0);
					this.boatPieces.put("r" + loc, Integer.valueOf(rowPieces)); // 'r' denotese these are rows
					this.piecesList.add(Integer.valueOf(rowPieces));

					for (int c = 0; c < this.boardSize; c++) {
						String character = "" + str.charAt(c + 1);
						if (character.equals(" ")) {
							this.currBoard[r][c] = "-";
						} else {
							this.currBoard[r][c] = character;
						}
					}
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			System.exit(1);
		}
	}

	/**
	 * Goes through the board and places boats and at the correct locations to solve
	 * the puzzle
	 * 
	 * @return true if there is a solution to the puzzle, false if not
	 */
	public boolean solveBoard() {
		return solveBoard(0, 0);
	}

	/**
	 * Goes through the board and places boats and water at legal positions to solve
	 * the puzzle
	 * 
	 * @param row the current row location
	 * @param col the current column location
	 * @return true if the game has been solved, false if not
	 */
	private boolean solveBoard(int row, int col) {
		if (row == this.boardSize) {
			return true;
		} else if (col == this.boardSize) {
			return solveBoard(row + 1, 0);
		} else if (this.currBoard[row][col] != "-") {
			return solveBoard(row, col + 1);
		} else {
			if (isLegalBoat(row, col)) {
				this.currBoard[row][col] = "B";

				if (solveBoard(row, col + 1)) {
					return true;
				}

				this.currBoard[row][col] = "-";
			}
			if (isLegalWater(row, col)) {
				this.currBoard[row][col] = "~";

				if (solveBoard(row, col + 1)) {
					return true;
				}

				this.currBoard[row][col] = "-";
			}
			return false;
		}
	}

	/**
	 * Checks to see if water can be placed at the current location
	 * 
	 * @param row the row to be inspected
	 * @param col the column to be inspected
	 * @return true if water can go at this location, false if not
	 */
	private boolean isLegalWater(int row, int col) {
		return wCheckRow(row) && wCheckCol(col);
	}

	/**
	 * Checks a row to see if a water piece can be placed there
	 * 
	 * @param row the row to check
	 * @return true if water can be placed there, false if not
	 */
	private boolean wCheckRow(int row) {
		int numPieces = 0;
		for (int c = 0; c < this.boardSize; c++) {
			if (this.currBoard[row][c].equals("~")) {
				numPieces++;
			}
		}
		String loc = Integer.toString(row);
		int legalPieces = this.boardSize - (this.boatPieces.get("r" + loc));

		if (numPieces < legalPieces) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Checks a column to see if a water piece can be placed there
	 * 
	 * @param col the column to inspect
	 * @return true if water can be placed there, false if not
	 */
	private boolean wCheckCol(int col) {
		int numPieces = 0;
		for (int r = 0; r < this.boardSize; r++) {
			if (this.currBoard[r][col].equals("~")) {
				numPieces++;
			}
		}
		String loc = Integer.toString(col);
		int legalPieces = this.boardSize - (this.boatPieces.get("c" + loc));

		if (numPieces < legalPieces) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Checks to see if a boat piece can be at a specified location
	 * 
	 * @param row the row number of the cell to be checked
	 * @param col the column number of the cell to be checked
	 * @return true if a boat piece can go there, false if not
	 */
	private boolean isLegalBoat(int row, int col) {
		return checkRow(row) && checkCol(col) && checkAdj(row, col) && boatCount(row,col);
	}

	/**
	 * Goes through the row to see how many boat pieces are in that row and compare
	 * that number to the number of boat pieces allowed in that row
	 *
	 * @param row the row number to go through
	 * @param val
	 * @return true if legal to put a boat piece in that row based on the number of
	 *         allowed pieces, false if putting a piece will exceed the allowed
	 *         amount for that row
	 */
	private boolean checkRow(int row) {
		int numPieces = 0;
		for (int c = 0; c < this.boardSize; c++) {
			if (this.currBoard[row][c].equals("B")) {
				numPieces++;
			}
		}
		String loc = Integer.toString(row);
		int legalPieces = this.boatPieces.get("r" + loc);

		if (numPieces < legalPieces) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Goes through the column to see how many boat pieces are in that column and
	 * compare that number to the number of boat pieces allowed in that column
	 * 
	 * @param col the column to inspect
	 * @return true legal to put a boat piece in that row based on the number of
	 *         allowed pieces, false if putting a piece will exceed the allowed
	 *         amount for that row
	 */
	private boolean checkCol(int col) {
		int numPieces = 0;
		for (int r = 0; r < this.boardSize; r++) {
			if (this.currBoard[r][col].equals("B")) {
				numPieces++;
			}
		}
		String loc = Integer.toString(col);
		int legalPieces = this.boatPieces.get("c" + loc);

		if (numPieces < legalPieces) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Checks around the current location to see if there are any adjacent pieces
	 * around the current location that would render this location illegal for a
	 * boat
	 * 
	 * @param row the current row location
	 * @param col the current column location
	 * @return true if a boat piece can go here based on adjacent pieces, false if
	 *         not
	 */
	private boolean checkAdj(int row, int col) {
		if ((row - 1 > 0 && col - 1 > 0) && (this.currBoard[row - 1][col - 1].equals("B"))) {
			return false;
		} else if ((row - 1 > 0 && col + 1 < this.boardSize) && (this.currBoard[row - 1][col + 1].equals("B"))) {
			return false;
		} else if ((row + 1 < this.boardSize && col - 1 > 0) && (this.currBoard[row + 1][col - 1].equals("B"))) {
			return false;
		} else if ((row + 1 < this.boardSize && col + 1 < this.boardSize)
				&& (this.currBoard[row + 1][col + 1].equals("B"))) {
			return false;
		}
		return true;
	}

	/**
	 * Counts the length of a boat either vertically or horizontally from teh
	 * current location
	 * 
	 * @param row       the current location row
	 * @param col       the current location column
	 * @param direction if the adjacent boat piece is located horizontally or
	 *                  vertically from the current location
	 * @return true of there are enough of that boat type (i.e. length) to be
	 *         placed, false if not
	 */
	private boolean boatCount(int row, int col) {
		int currBoatCount = 0;
		int currFour = 0;
		int currThree = 0;
		int currTwo = 0;
		int currOne = 0;
		int currExtra = 0;

		for (int r = 0; r < this.boardSize; r++) {
			for (int c = 0; c < this.boardSize; c++) {
				currBoatCount = countOneBoat(r, c);

				if (currBoatCount > 4) {
					currExtra++;
				}
				if (currBoatCount == 4) {
					currFour++;
				}
				if (currBoatCount == 3) {
					currThree++;
				}
				if (currBoatCount == 2) {
					currTwo++;
				}
				if(currBoatCount == 1) {
					currOne++;
				}
			}
		}
		
		for(int r = 0; r < this.boardSize; r++) {
			for(int c =0; c < this.boardSize; c++) {
				if(this.currBoard[r][c].equals("*")) {
					this.currBoard[r][c] = "B";
				}
			}
		}
		
		int posFour = this.boatsRem.get(4);
		int posThree = this.boatsRem.get(3) + (this.boatsRem.get(4) - currFour);
		int posTwo = this.boatsRem.get(2) + ((this.boatsRem.get(3) - currThree) + (this.boatsRem.get(4) - currFour));
		int posOne = this.boatsRem.get(1) + ((this.boatsRem.get(2) - currTwo) + (this.boatsRem.get(3) - currThree)
				+ (this.boatsRem.get(4) - currFour));
					
		if (currExtra > 0) {
			return false;
		}
		if (currFour > this.boatsRem.get(4)) {
			return false;
		}
		if (currThree >= posThree) {
			return false;
		}
		if (currTwo >= posTwo) {
			return false;
		}
		if (currOne >= posOne) {
			return false;
		}
		return true;
	}

	/**
	 * Counts the length of one boat. 
	 * 
	 * @param row the row location to start counting from
	 * @param col the column location to start counting from
	 * @return the length of the boat at the current location
	 */
	private int countOneBoat(int row, int col) {
		if (row < 0 || row >= this.boardSize || col < 0 || col >= this.boardSize || this.currBoard[row][col] != "B") {
			return 0;
		} else {
			this.currBoard[row][col] = "*";
			return 1 + this.countOneBoat(row - 1, col - 1) + this.countOneBoat(row - 1, col)
					+ this.countOneBoat(row - 1, col + 1) + this.countOneBoat(row, col - 1)
					+ this.countOneBoat(row, col + 1) + this.countOneBoat(row + 1, col - 1)
					+ this.countOneBoat(row + 1, col) + this.countOneBoat(row + 1, col + 1);
		}
	}

}

