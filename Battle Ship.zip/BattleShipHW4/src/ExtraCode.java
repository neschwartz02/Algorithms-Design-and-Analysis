
public class ExtraCode {

	/**
	 * Checks around the current location to see if there are any adjacent pieces around the 
	 * current location that would render this location illegal for a boat
	 * 
	 * @param row the current row location 
	 * @param col the current column location
	 * @return true if a boat piece can go here based on adjacent pieces, false if not
	 */
	private boolean checkAdj (int row, int col) {
		if(currBoard[row-1][col-1].equals("B") || currBoard[row-1][col+1].equals("B") || 
				currBoard[row+1][col-1].equals("B") || currBoard[row+1][col+1].equals("B")) { //checks to see if diagonals have boats
			return false;
		} 
		else if((currBoard[row-1][col].equals("B") && currBoard[row][col-1].equals("B")) || // diagonal pairs
				(currBoard[row-1][col].equals("B") && currBoard[row][col+1].equals("B"))) {
			return false;
		}
		else if((currBoard[row+1][col].equals("B") && currBoard[row][col-1].equals("B")) || // diagonal pairs
				(currBoard[row+1][col].equals("B") && currBoard[row][col+1].equals("B"))) {
			return false;
		}		
		else if(currBoard[row][col-1].equals("B") || currBoard[row][col+1].equals("B")) { //if the one left or right equals B and there are enough boat types
			if(boatCount(row, col, "h")) {
				return true;
			} 
		} 
		else if(currBoard[row-1][col].equals("B") || currBoard[row+1][col].equals("B") ) { //if the one above or below equals B and there are enough boat types
			if(boatCount(row, col, "v")) {
				return true;
			} 
		}
		return false;
	}
	
	/**
	 * 
	 * @param row
	 * @param col
	 * @param direction
	 * @return
	 */
	private boolean boatCount(int row, int col, String direction) {
		this.currBoard[row][col] = "B"; // temporary to get the right count
		int count = 0;
		
		if(direction.equals("v")) { // is it vertical
			if(currBoard[row-1][col].equals("B") && currBoard[row+1][col].equals("B") ||
					(currBoard[row+1][col].equals("B"))) { //both above and below or below
				int rowNum;
				if(row != boardSize) {
					rowNum = row + 1;
				} else {
					rowNum = row;
				}
				
				for(int i=0; i< boardSize; i++) {
					if(currBoard[rowNum][col].equals("B") && rowNum >= 0) {
						count++;
						rowNum = rowNum - 1;
					} else {
						break;
					}
				}
			} else if(currBoard[row-1][col].equals("B")) { // only above
				int rowNum = row;
				
				for(int i=0; i< boardSize; i++) {
					if(currBoard[rowNum][col].equals("B") && rowNum >= 0) {
						count++;
						rowNum = rowNum - 1;
					} else {
						break;
					}
				}
			}
		}
			
		if(direction.equals("h")) { // is it horizontal
			if((currBoard[row][col-1].equals("B") && currBoard[row][col+1].equals("B")) || 
					(currBoard[row][col-1].equals("B"))) { // to the left and right or just to the left
				
				int colNum;
				if(col != 0) { //makes sure that the index isn't out of bounds
					colNum = col - 1;
				} else  { 
					colNum = col; 
				}
				
				for(int i=0; i < boardSize; i++) {
					if(currBoard[row][colNum].equals("B") && colNum <= boardSize) {
						count++;
						colNum = colNum + 1;
					} else {
						break;
					}
				}
			} else if(currBoard[row][col+1].equals("B") ) { // only to the right
				
				int colNum = col;
				for(int i=0; i< boardSize; i++) {
					if(currBoard[row][colNum].equals("B") && colNum <= boardSize) {
						count++;
						colNum = colNum + 1;
					} else {
						break;
					}
				}
			}
		}
		
		this.currBoard[row][col] = "-"; // resetting this location to unfilled
		int newLength = count;
		
		if(newLength > 4 || newLength < 1) {
			return false;
		} else if(newLength > boatCounts.get(newLength)) { //checks to see if enough of that type remains
			boatCounts.replace(newLength, boatCounts.get(newLength)-1);
			return true;
		} else {  
			return false;
		}	
	}
}
}
