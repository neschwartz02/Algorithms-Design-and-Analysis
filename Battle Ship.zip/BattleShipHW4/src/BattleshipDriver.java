import java.util.Scanner;

/**
 * An class driver that solves a Battleship puzzle
 * 
 * @author Natalie Schwartzenberger
 * @version April 2021
 *
 */
public class BattleshipDriver {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("What is the name of the file you would like to use? ");
		String fileName = in.next();
		
		Battleship newGame = new Battleship(fileName);
		System.out.println(newGame.displaySolution());
		in.close();

	}

}
