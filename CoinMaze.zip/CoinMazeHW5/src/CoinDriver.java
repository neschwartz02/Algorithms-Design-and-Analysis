import java.util.Scanner;


/**
 * Driver clas for the coin mazeh homework
 * Homework 5 
 * CSC 425
 * Dr. Baker
 * @author natsc
 */
public class CoinDriver {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.println("What is the name of the file you would like to use? ");
		String fileName = in.next();
		
		CoinCollector newMaze = new CoinCollector(fileName);
		
		//for(int i = 0; i < 6; i++) {
			System.out.println("What is your starting point?");
			int rowNum = in.nextInt();			
			int colNum = in.nextInt();
				
			long topStart = System.nanoTime();
			int outputTop = newMaze.findMaxCoinsTopDown(rowNum,colNum);
			long elapsedTop = System.nanoTime() - topStart;
				
			long bottomStart = System.nanoTime();
			int outputBottom = newMaze.findMaxCoinsBottomUp(rowNum,colNum);
			long elapsedBottom = System.nanoTime() - bottomStart;
			
			System.out.println("D&C--> Input: ("+rowNum+", "+colNum+") Output:"+outputTop+" --> Time Elapsed: " + Long.toString(elapsedTop)+" nanoseconds");	
			System.out.println("DP --> Input: ("+rowNum+", "+colNum+") Output:"+outputBottom+" --> Time Elapsed: " + Long.toString(elapsedBottom)+ " nanoseconds");
			System.out.println();
		//}
		in.close();	
	}

}
