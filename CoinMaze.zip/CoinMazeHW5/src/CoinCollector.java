import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class CoinCollector {
	private int numCol;
	private int numRow;
	private String[][] maze;
	
	public CoinCollector(String filename) {
		try {
			Scanner infile = new Scanner(new File(filename));
				this.numRow = infile.nextInt();
				this.numCol = infile.nextInt();

			this.maze = new String[this.numRow][this.numCol];
			String str = infile.nextLine();

			while (infile.hasNextLine()) {
				for (int r = 0; r < this.numRow; r++) {
					str = infile.nextLine();
					for (int c = 0; c < this.numCol; c++) {
						String character = "" + str.charAt(c);
						if (character.equals(" ")) {
							this.maze[r][c] = "-";
						} else {
							this.maze[r][c] = character;
						}
					}
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			System.exit(1);
		}
	}
	
	public String display() {
		String s = "";
		for(int r = 0; r<this.numRow; r++) {
			for(int c = 0; c<this.numCol; c++) {
				s += String.valueOf(maze[r][c]);
			}
			s+="\n";
		}
		return s;
	}
	
	/**
	 *  Determines the maximum number of coins a robot can pick up on the way to their target location
	 *  using a top down approach.
	 *    @param startRow the initial row the robot starts in
	 *    @param startCol the initial column the robot starts in
	 *    @return the max number of coins that can be picked up on the way to the target destination, -1 
	 *    if it is not possible to reach the target destination from the starting point.
	 */
	public int findMaxCoinsTopDown(int startRow, int startCol) {
		return numCoins(startRow, startCol);
	}
	
	/**
	 * Private helper method to find the maximum number of coins to be gathered from one location 
	 * on the grid 
	 * @param row
	 * @param col
	 * @return
	 */
	private int numCoins(int row, int col) {
		if ((row < 0 || row >= this.numRow || col < 0 || col >= this.numCol) || this.maze[row][col].equals("x")) { 
			return -1;
		} 
		else if(row == this.numRow-1 && col == this.numCol-1) {
			if(this.maze[row][col].equals("c")) {
				return 1;
			} else {
				return 0;
			}
		} 
		else {
			int maxVal = Math.max(numCoins(row, col+1), numCoins(row+1, col)); 
				
			if(maxVal == -1) {
				return -1; 
			} 
			else if(this.maze[row][col].equals("c")) {
				return maxVal + 1;
			}
			else {
				return maxVal;
			}
		}
	}
	
	/**
	 *  Determines the maximum number of coins a robot can pick up on the way to their target location
	 *  using a top down approach.
	 *  
	 *    @param startRow the initial row the robot starts in
	 *    @param startCol the initial column the robot starts in
	 *    @return the max number of coins that can be picked up on the way to the target destination, -1 
	 *    if it is not possible to reach the target destination from the starting point.
	 */
	public int findMaxCoinsBottomUp(int startRow, int startCol) {
		int bottomGrid[][] = new int[this.numRow][this.numCol]; 
		
		if(startRow < 0 || startRow >= this.numRow || startCol < 0 || startCol >= this.numCol) {
			return -1;
		}
		
	    for (int r = this.numRow-1; r >= startRow; r--) {
	        for (int c = this.numCol-1; c >= startCol; c--) {
	        	
	        	if (this.maze[r][c].equals("x")){ 
	    			bottomGrid[r][c] = -1;
	    		} 
	        	else if(r == this.numRow-1 && c == this.numCol-1) {
	    			
	        		if(this.maze[r][c].equals("c")) {
	    				bottomGrid[r][c] = 1;
	    			} else {
	    				bottomGrid[r][c] = 0;
	    			}
	            } 
	        	else { 
	        		if((!(r >= this.numRow - 1))) {
		            	int maxVal = Math.max(bottomGrid[r+1][c], bottomGrid[r][c+1]);
		            	
		            	if(maxVal == -1) {
		            		bottomGrid[r][c] = -1;
		            	}
		            	else if(this.maze[r][c].equals("c")) {
		            		bottomGrid[r][c] = maxVal + 1 ;
		            	}
		            	else {
		            		bottomGrid[r][c] = maxVal;
		            	}
		            } else {
		            	return -1;
		            }
	        	}
	        }
	    }
	    return bottomGrid[startRow][startCol]; 
	}	
}